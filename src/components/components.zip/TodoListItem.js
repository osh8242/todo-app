import {
  MdCheckBox,
  MdCheckBoxOutlineBlank,
  MdRemoveCircleOutline,
} from 'react-icons/md';
import cn from '../../node_modules/classnames/index';
import './TodoListItem.scss';

const TodoListItem = ({ todo, onRemove, checkToggle }) => {
  const { title, checked } = todo;

  const onClick = (e) => {
    onRemove(todo.id);
  };

  const onClickCheck = (e) => {
    checkToggle(todo.id);
  };

  return (
    <div className="TodoListItem">
      <div className={cn('checkbox', { checked })}>
        {checked ? <MdCheckBox /> : <MdCheckBoxOutlineBlank />}
        <div className="text" onClick={onClickCheck}>
          {todo.title}
        </div>
      </div>
      <div className="remove" onClick={onClick}>
        <MdRemoveCircleOutline />
      </div>
    </div>
  );
};

export default TodoListItem;
